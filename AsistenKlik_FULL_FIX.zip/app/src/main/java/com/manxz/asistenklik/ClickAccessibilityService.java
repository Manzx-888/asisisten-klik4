package com.manxz.asistenklik;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class ClickAccessibilityService extends AccessibilityService {

    private static ClickAccessibilityService instance;
    private static MainActivity ui;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private static volatile boolean running = false;

    private static final int SCAN_DELAY_MS = 450;
    private static final int AFTER_CLICK_DELAY_MS = 1200;
    private static final int REFRESH_DELAY_MS = 900;

    private static final int MAX_LOGS = 150;
    private static final Deque<String> logs = new ArrayDeque<>();

    // Alur:
    // 1. Di Mutualan: cari tombol task Follow +20 / Like +10 lalu klik.
    // 2. Di TikTok/Instagram: cari aksi Follow/Ikuti atau Like/Suka lalu klik.
    // 3. Setelah aksi berhasil, kembali ke aplikasi sebelumnya dan refresh.
    private enum Stage { TASK, ACTION }
    private Stage stage = Stage.TASK;

    public static void setUi(MainActivity activity) {
        ui = activity;
        if (activity != null) activity.notifyUi();
    }

    public static boolean isRunning() {
        return running;
    }

    public static void start() {
        running = true;
        addLog("▶ SCAN DIMULAI");
        notifyUi();
    }

    public static void pause() {
        running = false;
        addLog("⏸ SCAN DI-PAUSE");
        notifyUi();
    }

    public static void clearLog() {
        synchronized (logs) {
            logs.clear();
        }
        notifyUi();
    }

    public static String getLog() {
        synchronized (logs) {
            StringBuilder b = new StringBuilder();
            for (String s : logs) b.append(s).append("\n");
            return b.toString();
        }
    }

    private static void addLog(String message) {
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date());
        synchronized (logs) {
            while (logs.size() >= MAX_LOGS) logs.removeFirst();
            logs.addLast("[" + time + "] " + message);
        }
        notifyUi();
    }

    private static void notifyUi() {
        if (ui != null) ui.notifyUi();
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        addLog("♿ Accessibility terhubung");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running || busy.get()) return;

        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            return;
        }

        handler.removeCallbacksAndMessages(SCAN_TOKEN);
        handler.postDelayed(() -> scan(), SCAN_DELAY_MS);
    }

    private static final Object SCAN_TOKEN = new Object();

    private void scan() {
        if (!running || busy.get()) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            addLog("Tidak bisa membaca layar aktif");
            return;
        }

        try {
            if (stage == Stage.TASK) {
                AccessibilityNodeInfo task = findTask(root);
                if (task != null) {
                    String label = nodeLabel(task);
                    addLog("TASK TERDETEKSI: " + label);
                    clickNode(task, "TASK " + label);
                    stage = Stage.ACTION;
                }
            } else {
                AccessibilityNodeInfo action = findAction(root);
                if (action != null) {
                    String label = nodeLabel(action);
                    addLog("AKSI TERDETEKSI: " + label);
                    clickNode(action, "AKSI " + label);
                    handler.postDelayed(() -> finishAction(), AFTER_CLICK_DELAY_MS);
                }
            }
        } finally {
            root.recycle();
        }
    }

    private AccessibilityNodeInfo findTask(AccessibilityNodeInfo root) {
        return findFirst(root, true);
    }

    private AccessibilityNodeInfo findAction(AccessibilityNodeInfo root) {
        return findFirst(root, false);
    }

    private AccessibilityNodeInfo findFirst(AccessibilityNodeInfo root, boolean task) {
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);

        while (!q.isEmpty()) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (n == null) continue;

            String label = nodeLabel(n).toLowerCase(Locale.ROOT);

            boolean match;
            if (task) {
                match = (label.contains("follow") && hasNumber(label))
                        || (label.contains("like") && hasNumber(label));
            } else {
                // Supports English and Indonesian UI labels.
                match = label.equals("follow")
                        || label.equals("ikuti")
                        || label.equals("like")
                        || label.equals("suka")
                        || label.contains("ikuti ")
                        || label.contains("follow ")
                        || label.contains("like ")
                        || label.contains("suka ");
            }

            if (match && n.isVisibleToUser() && n.isEnabled()) {
                return AccessibilityNodeInfo.obtain(n);
            }

            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo child = n.getChild(i);
                if (child != null) q.addLast(child);
            }
        }
        return null;
    }

    private boolean hasNumber(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (Character.isDigit(s.charAt(i))) return true;
        }
        return false;
    }

    private String nodeLabel(AccessibilityNodeInfo n) {
        CharSequence d = n.getContentDescription();
        if (d != null && d.length() > 0) return d.toString().trim();

        CharSequence t = n.getText();
        if (t != null && t.length() > 0) return t.toString().trim();

        return n.getClassName() == null ? "unknown" : n.getClassName().toString();
    }

    private void clickNode(AccessibilityNodeInfo node, String reason) {
        busy.set(true);

        boolean clicked = node.performAction(
                AccessibilityNodeInfo.ACTION_CLICK);

        if (clicked) {
            addLog("✓ KLIK BERHASIL: " + reason);
        } else {
            addLog("⚠ ACTION_CLICK gagal, mencoba parent...");
            AccessibilityNodeInfo p = node.getParent();
            boolean parentClicked = false;
            if (p != null) {
                parentClicked = p.performAction(
                        AccessibilityNodeInfo.ACTION_CLICK);
                p.recycle();
            }
            addLog(parentClicked
                    ? "✓ KLIK PARENT BERHASIL"
                    : "✗ GAGAL KLIK");
        }

        node.recycle();

        handler.postDelayed(() -> busy.set(false), AFTER_CLICK_DELAY_MS);
    }

    private void finishAction() {
        if (!running) return;

        addLog("✓ AKSI SELESAI");
        addLog("↩ KEMBALI KE APLIKASI TUGAS");

        performGlobalAction(GLOBAL_ACTION_BACK);

        handler.postDelayed(() -> {
            addLog("↻ REFRESH");
            swipeRefresh();

            handler.postDelayed(() -> {
                stage = Stage.TASK;
                busy.set(false);
                addLog("🔎 SCAN TASK LAGI");
                scan();
            }, REFRESH_DELAY_MS);
        }, AFTER_CLICK_DELAY_MS);
    }

    private void swipeRefresh() {
        // Swipe dari atas ke bawah untuk refresh pada layar yang mendukung pull-to-refresh.
        Path path = new Path();
        float x = getResources().getDisplayMetrics().widthPixels / 2f;
        path.moveTo(x, 300);
        path.lineTo(x, 1000);

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 450);

        dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                null,
                null);
    }

    @Override
    public void onInterrupt() {
        addLog("Accessibility diinterupsi");
    }

    @Override
    public void onDestroy() {
        running = false;
        instance = null;
        super.onDestroy();
    }
}
