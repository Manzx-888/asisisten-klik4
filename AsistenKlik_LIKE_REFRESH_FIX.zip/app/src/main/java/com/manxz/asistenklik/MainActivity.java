package com.manzx.asistenklik;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView status, logView;
    private Button playPause;
    private EditText taskDelay, actionDelay, backDelay, refreshDelay;

    @Override protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); buildUi(); refreshStatus(); ClickAccessibilityService.setUi(this); }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad,pad,pad,pad); root.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this); title.setText("ASISTEN KLIK"); title.setTextSize(26); title.setTextColor(Color.DKGRAY); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Deteksi Follow / Like otomatis"); sub.setTextSize(15); root.addView(sub);

        Button accessibility = new Button(this); accessibility.setText("1. AKTIFKAN ACCESSIBILITY"); accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(accessibility);
        Button overlay = new Button(this); overlay.setText("2. IZINKAN TAMPIL DI ATAS APLIKASI"); overlay.setOnClickListener(v -> { if (android.os.Build.VERSION.SDK_INT >= 23) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); }); root.addView(overlay);

        TextView delayTitle = new TextView(this); delayTitle.setText("PENGATURAN DELAY (milidetik)"); delayTitle.setTextSize(18); delayTitle.setPadding(0,dp(12),0,dp(4)); root.addView(delayTitle);
        taskDelay = delay("Setelah klik task", ClickAccessibilityService.getTaskDelayMs()); root.addView(taskDelay);
        actionDelay = delay("Setelah klik Follow/Like", ClickAccessibilityService.getActionDelayMs()); root.addView(actionDelay);
        backDelay = delay("Setelah kembali / BACK", ClickAccessibilityService.getBackDelayMs()); root.addView(backDelay);
        refreshDelay = delay("Setelah refresh", ClickAccessibilityService.getRefreshDelayMs()); root.addView(refreshDelay);
        Button saveDelay = new Button(this); saveDelay.setText("SIMPAN DELAY"); saveDelay.setOnClickListener(v -> saveDelays()); root.addView(saveDelay);

        playPause = new Button(this); playPause.setText("▶ MULAI SCAN"); playPause.setOnClickListener(v -> { if (ClickAccessibilityService.isRunning()) ClickAccessibilityService.pause(); else { saveDelays(); ClickAccessibilityService.start(); } refreshStatus(); }); root.addView(playPause);
        status = new TextView(this); status.setTextSize(15); status.setPadding(0,dp(12),0,dp(12)); root.addView(status);
        TextView logTitle = new TextView(this); logTitle.setText("LOG AKTIVITAS"); logTitle.setTextSize(18); root.addView(logTitle);
        logView = new TextView(this); logView.setTextSize(13); logView.setTextColor(Color.DKGRAY); logView.setPadding(dp(8),dp(8),dp(8),dp(8));
        ScrollView scroll = new ScrollView(this); scroll.addView(logView); root.addView(scroll,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f));
        Button clear = new Button(this); clear.setText("BERSIHKAN LOG"); clear.setOnClickListener(v -> { ClickAccessibilityService.clearLog(); updateLog(); }); root.addView(clear);
        setContentView(root);
    }

    private EditText delay(String hint, int value) { EditText e = new EditText(this); e.setHint(hint); e.setText(String.valueOf(value)); e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e.setSingleLine(true); return e; }
    private int value(EditText e, int fallback) { try { return Integer.parseInt(e.getText().toString().trim()); } catch(Exception ex) { return fallback; } }
    private void saveDelays() { ClickAccessibilityService.setDelays(value(taskDelay,1500), value(actionDelay,2500), value(backDelay,1500), value(refreshDelay,1800)); }

    @Override protected void onResume() { super.onResume(); refreshStatus(); updateLog(); }
    private void refreshStatus() { if(status!=null) status.setText("Accessibility: " + (isAccessibilityEnabled()?"AKTIF":"BELUM AKTIF")); if(playPause!=null) playPause.setText(ClickAccessibilityService.isRunning()?"⏸ PAUSE":"▶ MULAI SCAN"); }
    private void updateLog() { if(logView!=null) logView.setText(ClickAccessibilityService.getLog()); }
    public void notifyUi() { runOnUiThread(() -> { refreshStatus(); updateLog(); }); }
    private boolean isAccessibilityEnabled() { AccessibilityManager am=(AccessibilityManager)getSystemService(Context.ACCESSIBILITY_SERVICE); if(am==null)return false; for(AccessibilityServiceInfo info:am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)){ ComponentName cn=new ComponentName(this,ClickAccessibilityService.class); if(info.getResolveInfo()!=null&&info.getResolveInfo().serviceInfo!=null&&cn.getPackageName().equals(info.getResolveInfo().serviceInfo.packageName)&&cn.getClassName().equals(info.getResolveInfo().serviceInfo.name))return true;} return false; }
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
}
