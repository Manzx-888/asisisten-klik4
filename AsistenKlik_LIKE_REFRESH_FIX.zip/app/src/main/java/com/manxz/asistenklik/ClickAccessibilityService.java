package com.manzx.asistenklik;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class ClickAccessibilityService extends AccessibilityService {
    private static ClickAccessibilityService instance;
    private static MainActivity ui;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private static volatile boolean running = false;

    // Semua delay dapat diubah dari UI.
    private static volatile int taskDelayMs = 1500;
    private static volatile int actionDelayMs = 2500;
    private static volatile int backDelayMs = 1500;
    private static volatile int refreshDelayMs = 1800;
    private static final int SCAN_DELAY_MS = 500;

    private static final int MAX_LOGS = 200;
    private static final Deque<String> logs = new ArrayDeque<>();
    private enum Stage { TASK, ACTION }
    private Stage stage = Stage.TASK;

    private static final Object SCAN_TOKEN = new Object();

    public static void setUi(MainActivity activity) { ui = activity; if (activity != null) activity.notifyUi(); }
    public static boolean isRunning() { return running; }
    public static int getTaskDelayMs() { return taskDelayMs; }
    public static int getActionDelayMs() { return actionDelayMs; }
    public static int getBackDelayMs() { return backDelayMs; }
    public static int getRefreshDelayMs() { return refreshDelayMs; }

    public static void setDelays(int task, int action, int back, int refresh) {
        taskDelayMs = clamp(task, 0, 30000);
        actionDelayMs = clamp(action, 0, 30000);
        backDelayMs = clamp(back, 0, 30000);
        refreshDelayMs = clamp(refresh, 0, 30000);
        addLog("⏱ Delay: task=" + taskDelayMs + "ms, aksi=" + actionDelayMs + "ms, back=" + backDelayMs + "ms, refresh=" + refreshDelayMs + "ms");
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    public static void start() {
        running = true;
        addLog("▶ SCAN DIMULAI");
        notifyUi();
    }

    public static void pause() {
        running = false;
        handlerClear();
        if (instance != null) instance.busy.set(false);
        addLog("⏸ SCAN DI-PAUSE");
        notifyUi();
    }

    private static void handlerClear() {
        if (instance != null) instance.handler.removeCallbacksAndMessages(null);
    }

    public static void clearLog() { synchronized (logs) { logs.clear(); } notifyUi(); }
    public static String getLog() { synchronized (logs) { StringBuilder b = new StringBuilder(); for (String s : logs) b.append(s).append("\n"); return b.toString(); } }

    private static void addLog(String message) {
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        synchronized (logs) { while (logs.size() >= MAX_LOGS) logs.removeFirst(); logs.addLast("[" + time + "] " + message); }
        notifyUi();
    }
    private static void notifyUi() { if (ui != null) ui.notifyUi(); }

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; addLog("♿ Accessibility terhubung"); }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running || busy.get()) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;
        handler.removeCallbacksAndMessages(SCAN_TOKEN);
        handler.postDelayed(() -> scan(), SCAN_DELAY_MS);
    }

    private void scan() {
        if (!running || busy.get()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { addLog("⚠ Tidak bisa membaca layar aktif"); return; }
        try {
            if (stage == Stage.TASK) {
                AccessibilityNodeInfo task = findTask(root);
                if (task != null) {
                    String label = nodeLabel(task);
                    addLog("TASK TERDETEKSI: " + label);

                    // LIKE TASK: jangan klik task Like +10.
                    // Langsung tunggu sesuai delay lalu refresh dan scan ulang
                    // sampai menemukan task Follow.
                    String lowerLabel = label.toLowerCase(Locale.ROOT);
                    boolean isLikeTask = lowerLabel.contains("like") || lowerLabel.contains("suka");
                    boolean isFollowTask = lowerLabel.contains("follow") || lowerLabel.contains("ikuti");

                    if (isLikeTask && !isFollowTask) {
                        busy.set(true);
                        addLog("↻ LIKE TASK DILEWATI — TIDAK DIKLIK");
                        addLog("⏳ Tunggu " + taskDelayMs + "ms sebelum refresh");
                        handler.postDelayed(() -> {
                            if (!running) return;
                            addLog("↻ REFRESH KARENA LIKE TASK");
                            swipeRefresh();
                            addLog("⏳ Tunggu " + refreshDelayMs + "ms setelah refresh");
                            handler.postDelayed(() -> {
                                if (!running) return;
                                busy.set(false);
                                addLog("🔎 SCAN TASK LAGI");
                                scan();
                            }, refreshDelayMs);
                        }, taskDelayMs);
                        return;
                    }

                    // FOLLOW TASK: klik seperti biasa lalu lanjut ke aplikasi target.
                    if (isFollowTask && clickNode(task, "TASK " + label)) {
                        stage = Stage.ACTION;
                        addLog("⏳ Tunggu " + taskDelayMs + "ms sebelum cari tombol aksi");
                        handler.postDelayed(() -> { if (running) { busy.set(false); scan(); } }, taskDelayMs);
                    } else {
                        busy.set(false);
                    }
                }
            } else {
                AccessibilityNodeInfo action = findAction(root);
                if (action != null) {
                    String label = nodeLabel(action);
                    addLog("AKSI TERDETEKSI: " + label);
                    if (clickNode(action, "AKSI " + label)) {
                        addLog("✓ KLIK AKSI BERHASIL");
                        addLog("⏳ Tunggu " + actionDelayMs + "ms setelah klik aksi");
                        handler.postDelayed(() -> finishAction(), actionDelayMs);
                    } else {
                        addLog("✗ Aksi gagal diklik");
                        busy.set(false);
                    }
                }
            }
        } finally { root.recycle(); }
    }

    private AccessibilityNodeInfo findTask(AccessibilityNodeInfo root) { return findFirst(root, true); }
    private AccessibilityNodeInfo findAction(AccessibilityNodeInfo root) { return findFirst(root, false); }

    private AccessibilityNodeInfo findFirst(AccessibilityNodeInfo root, boolean task) {
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        while (!q.isEmpty()) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (n == null) continue;
            String label = nodeLabel(n).toLowerCase(Locale.ROOT).trim();
            boolean match;
            if (task) {
                match = ((label.contains("follow") || label.contains("ikuti")) && hasNumber(label)) || ((label.contains("like") || label.contains("suka")) && hasNumber(label));
            } else {
                // Prioritaskan tombol aksi yang tepat, bukan teks deskripsi/video.
                match = label.equals("follow") || label.equals("ikuti") || label.equals("like") || label.equals("suka")
                        || label.startsWith("follow ") || label.startsWith("ikuti ") || label.startsWith("like ") || label.startsWith("suka ");
            }
            if (match && n.isVisibleToUser() && n.isEnabled() && n.isClickable()) return AccessibilityNodeInfo.obtain(n);
            for (int i = 0; i < n.getChildCount(); i++) { AccessibilityNodeInfo child = n.getChild(i); if (child != null) q.addLast(child); }
        }
        return null;
    }

    private boolean hasNumber(String s) { for (int i = 0; i < s.length(); i++) if (Character.isDigit(s.charAt(i))) return true; return false; }
    private String nodeLabel(AccessibilityNodeInfo n) {
        CharSequence d = n.getContentDescription();
        if (d != null && d.length() > 0) return d.toString().trim();
        CharSequence t = n.getText();
        if (t != null && t.length() > 0) return t.toString().trim();
        return n.getClassName() == null ? "unknown" : n.getClassName().toString();
    }

    private boolean clickNode(AccessibilityNodeInfo node, String reason) {
        busy.set(true);
        boolean clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        if (!clicked) {
            AccessibilityNodeInfo p = node.getParent();
            if (p != null) { clicked = p.performAction(AccessibilityNodeInfo.ACTION_CLICK); p.recycle(); }
        }
        addLog(clicked ? "✓ KLIK BERHASIL: " + reason : "✗ GAGAL KLIK: " + reason);
        node.recycle();
        return clicked;
    }

    private void finishAction() {
        if (!running) return;
        addLog("✓ AKSI SELESAI");
        addLog("↩ KEMBALI KE APLIKASI TUGAS");
        performGlobalAction(GLOBAL_ACTION_BACK);
        addLog("⏳ Tunggu " + backDelayMs + "ms setelah BACK");
        handler.postDelayed(() -> {
            if (!running) return;
            addLog("↻ REFRESH TASK");
            swipeRefresh();
            addLog("⏳ Tunggu " + refreshDelayMs + "ms setelah refresh");
            handler.postDelayed(() -> {
                if (!running) return;
                stage = Stage.TASK;
                busy.set(false);
                addLog("🔎 SCAN TASK LAGI");
                scan();
            }, refreshDelayMs);
        }, backDelayMs);
    }

    private void swipeRefresh() {
        Path path = new Path();
        float x = getResources().getDisplayMetrics().widthPixels / 2f;
        float startY = 380f;
        float endY = 1050f;
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 550);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    @Override public void onInterrupt() { addLog("Accessibility diinterupsi"); }
    @Override public void onDestroy() { running = false; handlerClear(); instance = null; super.onDestroy(); }
}
