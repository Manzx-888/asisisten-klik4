package com.manzx.asistenklik;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    public static final String PREF = "asisten_click_pref";
    TextView status, log;
    Button play, pause, clear;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        log = findViewById(R.id.log);
        play = findViewById(R.id.play);
        pause = findViewById(R.id.pause);
        clear = findViewById(R.id.clear);

        findViewById(R.id.access).setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        findViewById(R.id.overlay).setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });

        play.setOnClickListener(v -> setRunning(true));
        pause.setOnClickListener(v -> setRunning(false));
        clear.setOnClickListener(v -> {
            getSharedPreferences(PREF, 0).edit().remove("logs").apply();
            log.setText("Belum ada log.");
        });

        refreshUi();
    }

    private void setRunning(boolean value) {
        getSharedPreferences(PREF, 0).edit().putBoolean("running", value).apply();
        ClickAccessibilityService.running = value;
        status.setText(value ? "● BERJALAN — scanning" : "Ⅱ DI-PAUSE");
        appendLog(value ? "PLAY: scanner dimulai" : "PAUSE: scanner dihentikan");
    }

    private void refreshUi() {
        boolean running = getSharedPreferences(PREF, 0).getBoolean("running", false);
        ClickAccessibilityService.running = running;
        status.setText(running ? "● BERJALAN — scanning" : "Ⅱ DI-PAUSE");
        String s = getSharedPreferences(PREF, 0).getString("logs", "");
        log.setText(s.isEmpty() ? "Belum ada log." : s);
    }

    public static void appendLog(android.content.Context c, String message) {
        android.content.SharedPreferences p = c.getSharedPreferences(PREF, 0);
        String old = p.getString("logs", "");
        String line = new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date()) + "  " + message;
        String next = old.isEmpty() ? line : old + "\n" + line;
        String[] lines = next.split("\\n");
        if (lines.length > 120) {
            StringBuilder sb = new StringBuilder();
            for (int i = lines.length - 120; i < lines.length; i++) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(lines[i]);
            }
            next = sb.toString();
        }
        p.edit().putString("logs", next).apply();
    }

    private void appendLog(String message) {
        appendLog(this, message);
        String s = getSharedPreferences(PREF, 0).getString("logs", "");
        log.setText(s);
    }
}
