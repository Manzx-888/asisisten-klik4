package com.manzx.asistenklik;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;

/**
 * Fixed workflow:
 * 1) Find a visible task containing "Follow" -> click it.
 * 2) Find a visible task containing "Like" -> do NOT click it; pull-to-refresh.
 * 3) Wait and scan again.
 * No manual target/rule configuration is required.
 */
public class ClickAccessibilityService extends AccessibilityService {
    public static volatile boolean running = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastScan = 0;
    private long lastAction = 0;
    private boolean actionPending = false;
    private String lastActionType = "";

    private static final long SCAN_THROTTLE_MS = 250;
    private static final long ACTION_COOLDOWN_MS = 1800;
    private static final long AFTER_ACTION_WAIT_MS = 1200;

    @Override public void onServiceConnected() {
        running = getSharedPreferences(MainActivity.PREF, 0)
                .getBoolean("running", false);
        MainActivity.appendLog(this, "Accessibility Service terhubung");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running || actionPending) return;

        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED &&
            type != AccessibilityEvent.TYPE_VIEW_CLICKED) {
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastScan < SCAN_THROTTLE_MS) return;
        if (now - lastAction < ACTION_COOLDOWN_MS) return;
        lastScan = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        try {
            if (findAndHandle(root)) return;
        } finally {
            root.recycle();
        }
    }

    private boolean findAndHandle(AccessibilityNodeInfo node) {
        if (node == null) return false;

        String text = value(node.getText());
        String desc = value(node.getContentDescription());
        String state = value(node.getStateDescription());
        String combined = (text + " " + desc + " " + state).trim();
        String lower = combined.toLowerCase(Locale.ROOT);

        // Follow has priority. This matches examples such as "Follow +20".
        if (lower.contains("follow")) {
            if (node.isVisibleToUser() && node.isEnabled()) {
                AccessibilityNodeInfo clickable = findClickable(node);
                if (clickable != null) {
                    actionPending = true;
                    lastAction = System.currentTimeMillis();
                    lastActionType = "FOLLOW";
                    MainActivity.appendLog(this, "FOLLOW ditemukan: " + combined + " -> klik");
                    final AccessibilityNodeInfo target = clickable;
                    handler.postDelayed(() -> {
                        if (running) {
                            boolean ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            MainActivity.appendLog(this, ok ? "FOLLOW berhasil diklik" : "FOLLOW gagal diklik");
                        }
                        safeRecycle(target);
                        finishAction();
                    }, 150);
                    return true;
                }
            }
        }

        // Like is intentionally NOT clicked. It triggers pull-to-refresh.
        if (lower.contains("like")) {
            if (node.isVisibleToUser()) {
                actionPending = true;
                lastAction = System.currentTimeMillis();
                lastActionType = "LIKE_REFRESH";
                MainActivity.appendLog(this, "LIKE ditemukan: " + combined + " -> refresh");
                handler.postDelayed(this::pullToRefresh, 150);
                return true;
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                if (findAndHandle(child)) {
                    safeRecycle(child);
                    return true;
                }
                safeRecycle(child);
            }
        }
        return false;
    }

    private AccessibilityNodeInfo findClickable(AccessibilityNodeInfo node) {
        if (node.isClickable() && node.isEnabled()) return AccessibilityNodeInfo.obtain(node);

        AccessibilityNodeInfo cur = node;
        for (int depth = 0; depth < 8; depth++) {
            AccessibilityNodeInfo parent = cur.getParent();
            safeRecycle(cur);
            cur = parent;
            if (cur == null) break;
            if (cur.isClickable() && cur.isEnabled()) return cur;
        }
        safeRecycle(cur);
        return null;
    }

    private void pullToRefresh() {
        if (!running) {
            actionPending = false;
            return;
        }

        if (android.os.Build.VERSION.SDK_INT < 24) {
            MainActivity.appendLog(this, "Refresh gesture tidak didukung Android < 7");
            finishAction();
            return;
        }

        // Pull down from the upper-middle area. Mutualan-style task lists commonly
        // expose swipe-to-refresh; this avoids relying on a hard-coded button/text.
        android.graphics.Point size = new android.graphics.Point();
        getDisplay().getRealSize(size);
        float x = size.x * 0.50f;
        float startY = Math.max(180f, size.y * 0.28f);
        float endY = Math.min(size.y * 0.70f, startY + 520f);

        Path path = new Path();
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 500);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke).build();

        boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                MainActivity.appendLog(ClickAccessibilityService.this, "REFRESH gesture selesai");
                handler.postDelayed(ClickAccessibilityService.this::finishAction,
                        AFTER_ACTION_WAIT_MS);
            }
            @Override public void onCancelled(GestureDescription g) {
                MainActivity.appendLog(ClickAccessibilityService.this, "REFRESH gesture dibatalkan");
                handler.postDelayed(ClickAccessibilityService.this::finishAction,
                        AFTER_ACTION_WAIT_MS);
            }
        }, null);

        if (!dispatched) {
            MainActivity.appendLog(this, "REFRESH gagal dikirim");
            finishAction();
        } else {
            MainActivity.appendLog(this, "REFRESH gesture dikirim");
        }
    }

    private void finishAction() {
        actionPending = false;
        lastAction = System.currentTimeMillis();
        lastActionType = "";
    }

    private static String value(CharSequence s) {
        return s == null ? "" : s.toString();
    }

    private static void safeRecycle(AccessibilityNodeInfo n) {
        if (n != null) {
            try { n.recycle(); } catch (Exception ignored) {}
        }
    }

    @Override public void onInterrupt() {
        actionPending = false;
        MainActivity.appendLog(this, "Accessibility Service interrupted");
    }
}
