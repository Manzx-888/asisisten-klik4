ASISTEN KLIK - FULL FIX

Flow:
Like +10 -> jangan klik -> delay -> refresh -> delay -> scan lagi.
Follow +20 -> terdeteksi -> refresh -> delay -> scan lagi.

Play/Pause dan log tersedia di aplikasi.

Catatan:
Versi ini tidak mengotomatisasi klik Follow/Like pada platform pihak ketiga.
Aksi eksternal dilakukan manual. Accessibility dipakai untuk deteksi label,
refresh layar, delay, Play/Pause, dan log.
