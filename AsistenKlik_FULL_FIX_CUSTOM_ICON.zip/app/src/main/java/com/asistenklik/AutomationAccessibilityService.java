package com.asistenklik;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class AutomationAccessibilityService extends AccessibilityService {
    private static volatile boolean running = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean busy = false;

    public static void setRunning(boolean value) {
        running = value;
        MainActivity.log(value ? "Automation aktif" : "Automation dijeda");
    }

    public static boolean isRunning() { return running; }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(!running || busy) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if(root == null) return;

        if(find(root, "Like +10") != null) {
            busy = true;
            MainActivity.log("Like +10 → JANGAN KLIK");
            delayThen(() -> {
                MainActivity.log("Delay → REFRESH");
                refreshGesture();
                delayThen(() -> {
                    MainActivity.log("Delay → SCAN LAGI");
                    busy = false;
                });
            });
            return;
        }

        if(find(root, "Follow +20") != null) {
            busy = true;
            MainActivity.log("Follow +20 terdeteksi");
            MainActivity.log("Aksi Follow eksternal dilewati — lakukan manual");
            delayThen(() -> {
                MainActivity.log("REFRESH");
                refreshGesture();
                delayThen(() -> {
                    MainActivity.log("SCAN LAGI");
                    busy = false;
                });
            });
        }
    }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo node, String target) {
        CharSequence d = node.getContentDescription();
        CharSequence t = node.getText();
        if((d != null && target.equalsIgnoreCase(d.toString().trim())) ||
           (t != null && target.equalsIgnoreCase(t.toString().trim()))) return node;

        List<AccessibilityNodeInfo> m = node.findAccessibilityNodeInfosByText(target);
        if(m != null && !m.isEmpty()) return m.get(0);

        for(int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo c = node.getChild(i);
            if(c != null) {
                AccessibilityNodeInfo r = find(c,target);
                if(r != null) return r;
            }
        }
        return null;
    }

    private void delayThen(Runnable r) {
        long ms = 3000;
        MainActivity a = MainActivity.getInstance();
        if(a != null) ms = a.getDelayMs();
        handler.postDelayed(r, ms);
    }

    private void refreshGesture() {
        Path p = new Path();
        p.moveTo(540, 450);
        p.lineTo(540, 1050);
        GestureDescription.StrokeDescription s =
            new GestureDescription.StrokeDescription(p,0,500);
        dispatchGesture(new GestureDescription.Builder().addStroke(s).build(), null, null);
    }

    @Override public void onInterrupt() { busy = false; }
    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
