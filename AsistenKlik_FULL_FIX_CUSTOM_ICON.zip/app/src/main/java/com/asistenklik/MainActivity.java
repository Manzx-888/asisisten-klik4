package com.asistenklik;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static MainActivity instance;
    private TextView status, log;
    private EditText delay;

    public static MainActivity getInstance() { return instance; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        instance = this;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("ASISTEN KLIK");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        status = new TextView(this);
        status.setTextSize(18);
        status.setPadding(0,20,0,20);
        box.addView(status);

        Button play = new Button(this);
        play.setText("▶ PLAY");
        play.setOnClickListener(v -> {
            AutomationAccessibilityService.setRunning(true);
            refreshUi();
            addLog("PLAY");
        });
        box.addView(play);

        Button pause = new Button(this);
        pause.setText("⏸ PAUSE");
        pause.setOnClickListener(v -> {
            AutomationAccessibilityService.setRunning(false);
            refreshUi();
            addLog("PAUSE");
        });
        box.addView(pause);

        delay = new EditText(this);
        delay.setInputType(InputType.TYPE_CLASS_NUMBER);
        delay.setText("3000");
        delay.setHint("Delay (ms)");
        box.addView(delay);

        Button access = new Button(this);
        access.setText("BUKA AKSESIBILITY");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(access);

        TextView lt = new TextView(this);
        lt.setText("LOG");
        lt.setTextSize(18);
        lt.setPadding(0,20,0,8);
        box.addView(lt);

        log = new TextView(this);
        log.setText("Belum ada aktivitas.\n");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(log);
        box.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        setContentView(box);
        refreshUi();
    }

    public long getDelayMs() {
        try { return Math.max(0, Long.parseLong(delay.getText().toString().trim())); }
        catch(Exception e) { return 3000; }
    }

    public void refreshUi() {
        if(status != null)
            status.setText(AutomationAccessibilityService.isRunning() ? "● PLAYING" : "● PAUSED");
    }

    public void addLog(String s) {
        if(log != null) log.append(s + "\n");
    }

    public static void log(String s) {
        if(instance != null) instance.runOnUiThread(() -> instance.addLog(s));
    }
}
